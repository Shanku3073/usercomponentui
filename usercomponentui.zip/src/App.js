import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import ListUserComponent from "./component/user/ListUserComponent";
import AddUserComponent from "./component/user/AddUserComponent";
import EditUserComponent from "./component/user/EditUserComponent";
import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';

// Be sure to include styles at some point, probably during your bootstraping
import '@trendmicro/react-sidenav/dist/react-sidenav.css';
function App() {
  return (
      <div className="container">

          <SideNav
              onSelect={(selected) => {
                  // Add your code here
              }}
          >
              <SideNav.Toggle />
              <SideNav.Nav defaultSelected="home">
                  <NavItem eventKey="home">
                      <NavIcon>
                          <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
                      </NavIcon>
                      <NavText>
                          Home
                      </NavText>
                  </NavItem>
                  <NavItem eventKey="charts">
                      <NavIcon>
                          <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} />
                      </NavIcon>
                      <NavText>
                          Charts
                      </NavText>
                      <NavItem eventKey="charts/linechart">
                          <NavText>
                              Line Chart
                          </NavText>
                      </NavItem>
                      <NavItem eventKey="charts/barchart">
                          <NavText>
                              Bar Chart
                          </NavText>
                      </NavItem>
                  </NavItem>
              </SideNav.Nav>
          </SideNav>

          <Router>

              <div className="col-md-6">
                  <h1 className="text-center" style={style}>React User Application</h1>
                  <Switch>
                      <Route path="/" exact component={ListUserComponent} />
                      <Route path="/users" component={ListUserComponent} />
                      <Route path="/add-user" component={AddUserComponent} />
                      <Route path="/edit-user" component={EditUserComponent} />
                  </Switch>
              </div>
          </Router>
      </div>
  );
}

const style = {
    color: 'red',
    margin: '10px'
}

export default App;
