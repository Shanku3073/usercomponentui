import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import ListUserComponent from "./component/user/ListUserComponent";
import AddUserComponent from "./component/user/AddUserComponent";
import EditUserComponent from "./component/user/EditUserComponent";
import bundle from "./component/example/bundle";
import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';

// Be sure to include styles at some point, probably during your bootstraping
import '@trendmicro/react-sidenav/dist/react-sidenav.css';
function App() {
  return (
      <div className="container">
          <h1 className="text-center" style={style}>User Application</h1>
          <Router>
               <Route render={({ location, history }) => (
                  <React.Fragment>
                      <SideNav
                          onSelect={(selected) => {
                              const to = '/' + selected;
                              if (location.pathname !== to) {
                                  history.push(to);
                              }
                          }}
                      >
                          <SideNav.Toggle />
                          <SideNav.Nav defaultSelected="home">
                              <NavItem eventKey="home">
                                  <NavIcon>
                                      <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
                                  </NavIcon>
                                  <NavText>
                                      Home
                                  </NavText>
                              </NavItem>
                              <NavItem eventKey="adduser">
                                  <NavIcon>
                                      <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
                                  </NavIcon>
                                  <NavText>
                                     AddUser
                                  </NavText>
                              </NavItem>
                              <NavItem eventKey="calendar">
                                  <NavIcon>
                                      <i className="fa fa-fw fa-device" style={{ fontSize: '1.75em' }} />
                                  </NavIcon>
                                  <NavText>
                                     Calendar
                                  </NavText>
                              </NavItem>
                          </SideNav.Nav>
                      </SideNav>
                      <main>
                          <div className="col-md-6">
                          <Route path="/" exact component={ListUserComponent} />
                          <Route path="/home" component={ListUserComponent} />
                          <Route path="/adduser" component={AddUserComponent} />
                          <Route path="/calendar" component={bundle} />
                          </div>
                      </main>
                  </React.Fragment>
              )}
              />


          </Router>
      </div>
  );
}

const style = {
    color: 'red',
    margin: '10px'
}

export default App;
