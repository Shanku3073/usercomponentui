import React, { Component } from 'react'
import ApiService from "../../service/ApiService";
import Select from "react-dropdown-select";
import ReactRadioGroup from 'react-simple-radio-button';

const maritalStatus = [
    { value: 'Married', label: 'Marrried' },
    { value: 'Single', label: 'Single' },
    { value: 'Unknown', label: 'Unknown' },
];

class AddUserComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            username: '',
            password: '',
            firstName: '',
            lastName: '',
            age: '',
            salary: '',
            displayMenu: false,
            gender: '',
            message: null
        }

        this.saveUser = this.saveUser.bind(this);



       // this.showDropdownMenu = this.showDropdownMenu.bind(this);
     //   this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
    }



    saveUser = (e) => {
        e.preventDefault();
        let user = {username: this.state.username, password: this.state.password, firstName: this.state.firstName, lastName: this.state.lastName, age: this.state.age, salary: this.state.salary};
        ApiService.addUser(user)
            .then(res => {
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/users');
            });
    }

    showDropdownMenu(event) {
        event.preventDefault();
        this.setState({ displayMenu: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu);
        });
    }



    hideDropdownMenu() {
        this.setState({ displayMenu: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu);
        });

    }


    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {

        return(
            <div>
                <h2 className="text-center">Add User</h2>
                <form>
                <div className="form-group">
                    <label>User Name:</label>
                    <input type="text" placeholder="username" name="username" className="form-control" value={this.state.username} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Password:</label>
                    <input type="password" placeholder="password" name="password" className="form-control" value={this.state.password} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>First Name:</label>
                    <input placeholder="First Name" name="firstName" className="form-control" value={this.state.firstName} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Last Name:</label>
                    <input placeholder="Last name" name="lastName" className="form-control" value={this.state.lastName} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Age:</label>
                    <input type="number" placeholder="age" name="age" className="form-control" value={this.state.age} onChange={this.onChange}/>
                </div>

                    <div className="form-group">
                        <label>Gender:</label>

                        <ReactRadioGroup
                            defaultSelected = 'Male'
                            onChange={this.state.gender}
                            options={['Male','Female']}
                        />

                    </div>


                    <div classname="form-group">
                        <label>MaritalStatus:</label>
                        <Select
                            placeholder=""
                           disabled={this.state.disabled}
                            loading={this.state.loading}
                            searchBy={this.state.searchBy}
                            separator={this.state.separator}
                            clearable={this.state.clearable}
                            forceOpen={this.state.forceOpen}
                            handle={this.state.handle}
                            multi={this.state.multi}
                            values={[maritalStatus[0]]}
                            options={maritalStatus}
                            onDropdownOpen={() => undefined}
                            onDropdownClose={() => undefined}
                            onChange={(values) => this.setValues(values)}
                            contentRenderer={
                                this.state.contentRenderer
                                    ? (innerProps, innerState) => this.contentRenderer(innerProps, innerState)
                                    : undefined
                            }
                            dropdownRenderer={
                                this.state.dropdownRenderer
                                    ? (innerProps, innerState, innerMethods) =>
                                        this.dropdownRenderer(innerProps, innerState, innerMethods)
                                    : undefined
                            }
                        />

                    </div>



                <div className="form-group">
                    <label>Salary:</label>
                    <input type="number" placeholder="salary" name="salary" className="form-control" value={this.state.salary} onChange={this.onChange}/>
                </div>

                    <div className="form-group files">
                        <label>Upload Your File </label>
                        <input type="file" className="form-control" multiple=""/>
                    </div>

                    <div className="form-group">
                        <label>Additional Information:</label>
                    <textarea>

                        Hello there, this is some text in a text area
                    </textarea>
                    </div>



                <button className="btn btn-success" onClick={this.saveUser}>Save</button>
            </form>
    </div>
        );
    }
}

export default AddUserComponent;